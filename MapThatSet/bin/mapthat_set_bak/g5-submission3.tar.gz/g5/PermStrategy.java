package mapthatset.g5;

import java.util.ArrayList;

import mapthatset.sim.GuesserAction;

public class PermStrategy extends Strategy {

	public PermStrategy(boolean debug) {
		super(debug);
	}

	@Override
	public void startNewMapping(int mappingLength) {
		// TODO Auto-generated method stub
	}

	@Override
	public GuesserAction nextAction() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setResult(ArrayList<Integer> result) {
		// TODO Auto-generated method stub
	}

}
